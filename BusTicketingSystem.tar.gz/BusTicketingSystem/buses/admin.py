from django.contrib import admin

# Register your models here.
from buses.models import BusCompany, Bus


class BusLine(admin.TabularInline):
    model = Bus
    extra = 0


@admin.register(BusCompany)
class BusCompanyAdmin(admin.ModelAdmin):
    search_fields = ('name',)
    inlines = [BusLine]

@admin.register(Bus)
class BusAdmin(admin.ModelAdmin):
    list_display = ['serial_number','operator','seat_count']
    list_filter = ['operator']

