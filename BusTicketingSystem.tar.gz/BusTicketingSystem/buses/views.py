from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin
from django.http import HttpRequest, HttpResponse
from django.shortcuts import render
from django.views.generic import ListView, CreateView, UpdateView, DeleteView

from buses.models import BusCompany

class BusCompanyListView(LoginRequiredMixin, ListView):
    model = BusCompany
    template_name = 'buses/list.html'
    context_object_name = 'buses'

class BusCompanyCreateView(UserPassesTestMixin, CreateView):
    model = BusCompany
    template_name = 'buses/add.html'
    fields = ('name', 'head_office', 'staff_count')
    success_url = '/index'
    def test_func(self):
        return self.request.user.has_perm('buses.add_buscompany')

class BusComanyUpdateView(UserPassesTestMixin, UpdateView):
    model = BusCompany
    template_name = 'buses/edit.html'
    fields = ('name', 'head_office', 'staff_count')
    success_url = '/index'
    def test_func(self):
        return self.request.user.has_perm('buses.change_buscompany')

class BusComanyDeleteView(UserPassesTestMixin, DeleteView):
    model = BusCompany
    template_name = 'buses/delete.html'
    fields = ('name', 'head_office', 'staff_count')
    success_url = '/index'
    def test_func(self):
        return self.request.user.has_perm('buses._delete_buscompany')

def welcomepage(request:HttpRequest):
    return HttpResponse(request,'buses/welcome.html')

