
from django.urls import path
from buses import views

urlpatterns = [
    path('add/', views.BusCompanyCreateView.as_view()),
    path('index/', views.BusCompanyListView.as_view()),
    path('edit/<int:pk>/', views.BusComanyUpdateView.as_view()),
    path('delete/<int:pk>/', views.BusComanyDeleteView.as_view()),
    path('', views.welcomepage),
]
